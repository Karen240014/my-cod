$(document).ready(function(){
	$(".gcer").click(function(){
		$(".menu").removeClass("menu2");
	})
	$(".text1").click(function(){
		$(".menu").addClass("menu2");
	})
})