$(document).ready(function(){
    $(".log").click(function(){
        $(".div10").removeClass("div10l")
    })
});

$(".login-btn").click(function (e){

    e.preventDefault();

    let login = $('input[name="login"]').val();
    let password = $('input[name="password"]').val();

    $.ajax({
        url:'../vendor/signin.php',
        type: 'POST',
        dataType: 'text',
        data:{
            login: login,
            password: password
        },
        success: function (data){

        }
    });

})
