<?php
    session_start();
    if($_SESSION['user']){
        header('Location ../profile.php');
    }
?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
<div class="pat">
    <div class="menu">
        <div>
            <a href="index.php" class="text1">FILMS</a>
        </div>


        <div class="login">
            <a href="index.php" class="log">Войти</a>
            <a href="register.php" class="reg">Регистрация</a>
        </div>
    </div>

            <div class="div12">
                <div class="div11 ">
                    <form class="form2" action="vendor/signup.php" method="post">
                        <input type="text" name="full_name" placeholder="Введите имя и фамилия">
                        <input type="text" name="login" placeholder="Введите логин">
                        <input type="email" name="email" placeholder="Введите адрес почты">
                        <input type="password" name="password" placeholder="Введите пароль">
                        <input type="password" name="password_confirm" placeholder="Потдверждения пароль">
                        <button type="submit">Войти</button>
                        <p>
                            У вас уже есть аккаунт? - <a href="index.php">Авторизуйтесь</a>
                        </p>
                        <?php
                            if($_SESSION['message']){
                                echo '<p class="msg"> ' . $_SESSION['message'] . ' </p>';
                            }
                        unset($_SESSION['message']);
                        ?>
                    </form>
                </div>
            </div>



    <div class="div13">
        <div class="div2">
            <h4>Социальные сети</h4>
            <div class="div14">
                <div class="div15">
                    <a href="##"><i class="fa-brands fa-facebook"></i></a>
                    <a href="##"><i class="fa-brands fa-instagram"></i></a>
                    <a href="##"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="##"><i class="fa-brands fa-viber"></i></a>
                    <a href="##"><i class="fa-brands fa-vk"></i></a>
                </div>
            </div>
        </div>
    </div>



<script
    src="https://code.jquery.com/jquery-3.6.1.js"
    integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI="
    crossorigin="anonymous"></script>

<script src="js/script.js"></script>

<script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>
</body>
</html>