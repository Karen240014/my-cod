<?php
    session_start();
    if($_SESSION['user']){
        header('Location ../profile.php');
    }
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
    />
    <title>Document</title>
</head>
<body>
    <div class="pat">
        <div class="menu">
            <div>
                <a href="index.php" class="text1">FILMS</a>
            </div>
            <ul>
                <li>
                    <a href="">Фильмы</a>
                    <a href="">Сериалы</a>
                    <a href="">Мултфильмы</a>
                    <a href="">Телеканалы</a>
                </li>
            </ul>
            <div class="poisk">
                <form action="">
                    <input type="text" placeholder="SEARCH">
                    
                </form>
            </div>
            <div class="login">
                <a href="##" class="log">Войти</a>
                <a href="register.php" class="reg">Регистрация</a>
            </div>
        </div>

        <div class="div1">
            <div class="div2">
                <div class="div10 div10l">
                    <form  class="form1">
                        <input type="text" name="login" placeholder="Введите логин">
                        <input type="password" name="password" placeholder="Введите пароль">
                        <button type="submit" class="login-btn">Войти</button>
                        <p>
                            У вас нет аккаунта? - <a href="register.php">Зарегистрируйтесь</a>
                        </p>
                       <p class="msg">Lorem ipsum dolor sit amet.</p>
                    </form>
                </div>
                <h2 class="animate__animated animate__bounce">ПОПУЛЯРНЫЕ ФИЛЬМЫ ОНЛАЙН</h2>
                <div class="div3">
                    <a class="text2">ЖАНР</a>
                    <a class="text3">ГОД</a>
                </div>
                <div class="div4" data-aos="flip-left">
                    <div class="div5">
                        <img src="../filmimg/kino1.jpeg" alt="">
                        <p class="text4">Сезон акул</p>
                        <p>2020, Ужасы</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino2.jpg" alt="">
                        <p class="text4">Бурные воды</p>
                        <p>2019, Криминал</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino3.jpg" alt="">
                        <p class="text4">Последний богатырь</p>
                        <p>2019, Фэнтези/Комедия</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino4.jpeg" alt="">
                        <p class="text4">Супер агенты</p>
                        <p>2022, Комедия</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                </div>
                <div class="div4" data-aos="flip-left">
                    <div class="div5">
                        <img src="../filmimg/kino4.jpeg" alt="">
                        <p class="text4">Супер агенты</p>
                        <p>2022, Комедия</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino3.jpg" alt="">
                        <p class="text4">Последний богатырь</p>
                        <p>2019, Фэнтези/Комедия</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino2.jpg" alt="">
                        <p class="text4">Бурные воды</p>
                        <p>2019, Криминал</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino1.jpeg" alt="">
                        <p class="text4">Сезон акул</p>
                        <p>2020, Ужасы</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                </div>
                <div class="div4" data-aos="flip-left">
                    <div class="div5">
                        <img src="../filmimg/kino1.jpeg" alt="">
                        <p class="text4">Сезон акул</p>
                        <p>2020, Ужасы</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino2.jpg" alt="">
                        <p class="text4">Бурные воды</p>
                        <p>2019, Криминал</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino3.jpg" alt="">
                        <p class="text4">Последний богатырь</p>
                        <p>2019, Фэнтези/Комедия</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                    <div class="div5">
                        <img src="../filmimg/kino4.jpeg" alt="">
                        <p class="text4">Супер агенты</p>
                        <p>2022, Комедия</p>
                        <p class="text5">БЕСПЛАТНО</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="div13">
            <div class="div2">
                <h4>Социальные сети</h4>
                <div class="div14">
                    <div class="div15">
                        <a href="##"><i class="fa-brands fa-facebook"></i></a>
                        <a href="##"><i class="fa-brands fa-instagram"></i></a>
                        <a href="##"><i class="fa-brands fa-whatsapp"></i></a>
                        <a href="##"><i class="fa-brands fa-viber"></i></a>
                        <a href="##"><i class="fa-brands fa-vk"></i></a>
                    </div>
                </div>
            </div>
        </div>


    <script
            src="https://code.jquery.com/jquery-3.6.1.js"
            integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI="
            crossorigin="anonymous"></script>

    <script src="js/script.js"></script>

    <script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>



    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>
</html>
