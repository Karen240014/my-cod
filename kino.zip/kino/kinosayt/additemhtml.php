<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="glavadd">
    <div class="add">
        <div class="addclose">
                <a href="adminhtml.php"><button><i class="fa-solid fa-xmark"></i></button></a>
            </div>
        <h2>Add data</h2>
        <div class="addform">
            <form action="config/adminadd.php" method="post" name="admin" enctype="multipart/form-data">
                <h3>Director name</h3>
                <input type="text" name="directorname">
                <h3>Actor name</h3>
                <input type="text" name="actorname" id="">
                <br>
                <h4 class="msg none"></h4>
                <br>
                <button type="submit" class="add_done">Add</button>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM="
        crossorigin="anonymous"></script>
<script src="js/scriptadminadd.js"></script>
</body>
</html>
