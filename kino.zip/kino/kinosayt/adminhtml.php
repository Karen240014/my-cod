<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="glavadm">
    <div class="adm">
        <div class="admclose">
                <a href="index.php"><button><i class="fa-solid fa-xmark"></i></button></a>
            </div>
        <h2>Add film</h2>
        <div class="admform">
            <form action="config/admin.php" method="post" name="admin" enctype="multipart/form-data">
                <h3>Film name</h3>
                <input type="text" name="filmname">
                <h3>Rejisor</h3>
                <select name="rejisor"  class="rejselect" id="">
                    <option value="" disabled selected>Choose option</option>
                </select>
                <h3>Actors</h3>
                <select name="actors" class="actselect" id="" multiple>
                    <option value="" disabled selected>Choose option</option>
                </select>
                <h3>Year</h3>
                <select name="year" class="yearsselect" id="">
                    <option value="" disabled selected>Choose option</option>
                </select>
                <h3>Janre</h3>
                <select name="janre" class="janreselect" id="" multiple>
                    <option value="" disabled selected>Choose option</option>
                </select>
                <h3>description</h3>
                <input type="text" name="description" id="">
                <br>
                <h3>Choose img</h3>
                <input type="file" name="img">
                <h4 class="msg none"></h4>
                <br>
                <button type="submit" class="adm_done">Done</button>
            </form>
            <div class="admadd">
                <a href="additemhtml.php"><button class="adm_add">ДОБАВИТЬ ДАННЫЕ</button></a>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM="
        crossorigin="anonymous"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/scriptadmin.js"></script>
<script src="js/scriptadmin1.js"></script>
</body>
</html>
