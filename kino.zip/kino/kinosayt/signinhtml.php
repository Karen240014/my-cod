<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="glavsignin">
    <div class="sign">
        <div class="signclose"><a href="index.php">
                <a href="index.php"><button><i class="fa-solid fa-xmark"></i></button></a>
            </a></div>
        <h1>ShowHub</h1>
        <h2>Sign in to ShowHub</h2>
        <div class="signform">
            <form action="config/signin.php" method="post" name="signin" enctype="multipart/form-data">
                <h3>email </h3>
                <input type="email" name="email">
                <h3>Password</h3>
                <input type="password" name="password">
                <h4 class="msg none"></h4>
                <button type="submit" class="login_btn">Sign in</button>
            </form>
        </div>
        <div class="signreg">
            <h4>New to ShowHub? <a href="signuphtml.php">Create an account</a> .</h4>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E="
        crossorigin="anonymous"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/scriptsignin.js"></script>
</body>
</html>

