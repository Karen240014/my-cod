<?php
require "config/connect.php";
require "config/film.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>
</head>
<body>
<?

    $filmId = $_GET["id"];
for($i=0; $i<count($cat_arr); $i++){
    if($filmId == $cat_arr[$i][0]){
        $film=$cat_arr[$i];
    }
}
?>
<div class="menu">
    <div class="menu1">
        <div class="menlogo">
            <a href="index.php"><h1>ShowHub</h1></a>
        </div>
        <div class="mentext">
            <a href="cataloghtml.php">Movies</a>
            <a href="">Series</a>
            <a href="">Contact</a>
            <a href="">About Us</a>
            <div class="mediamen">
                <div class="mediamen1">
                    <h4>menu <i class="fa-solid fa-chevron-down"></i></h4>
                </div>
                <div class="mediamen2">
                    <a href="cataloghtml.php">Movies</a>
                    <a href="">Series</a>
                    <a href="">Contact</a>
                    <a href="">About Us</a>
                </div>
            </div>
        </div>
        <div class="meninp">
            <form action="">
                <input type="text" placeholder="Search">
                <h2><i class="fa-solid fa-magnifying-glass"></i></h2>
            </form>
        </div>
    </div>
    <div class="mensign">
        <a class="menbtn1a" href="signinhtml.php"><button class="menbtn1">log in</button></a>
        <a href="adminhtml.php"><button class="menbtn2">Admin</button></a>
    </div>
</div>
<div class="filmglav">
    <div class="film1">
        <h1><?=$film[1]?></h1>
        <div class="filmdescript">
            <div class="filmdesimg">
                <img src="<?=$film[5]?>" alt="">
            </div>
            <div class="filmdestext">
                <h2>Year: <span><?=$film[2]?></span></h2>
                <h2>Rejisor: <span><?=$film[3]?></span></h2>
                <h2>Actors: <span><?=$film[6]?></span></h2>
                <h2>Genre: <span><?=$film[7]?></span></h2>
                <h2>Description: <span><?=$film[4]?></span></h2>
            </div>
        </div>
        <div class="filmvideo">
            <img src="img/vid.jpg" alt="">
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM="
        crossorigin="anonymous"></script>
<script src="js/scriptsignin.js"></script>
<script src="js/scriptcatalog.js"></script>
<script src="js/scriptlogout.js"></script>
<script src="js/scriptfilm.js"></script>
<script src="js/script.js"></script>
</body>
</html>