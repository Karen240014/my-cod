<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="menu">
    <div class="menu1">
        <div class="menlogo">
            <a href="index.php"><h1>ShowHub</h1></a>
        </div>
        <div class="mentext">
            <a href="cataloghtml.php">Movies</a>
            <a href="">Series</a>
            <a href="">Contact</a>
            <a href="">About Us</a>
            <div class="mediamen">
                <div class="mediamen1">
                    <h4>menu <i class="fa-solid fa-chevron-down"></i></h4>
                </div>
                <div class="mediamen2">
                    <a href="cataloghtml.php">Movies</a>
                    <a href="">Series</a>
                    <a href="">Contact</a>
                    <a href="">About Us</a>
                </div>
            </div>
        </div>
        <div class="meninp">
            <form action="config/search.php" method="get" enctype="multipart/form-data">
                <input type="text" required placeholder="Search" name="search">
                <button type="submit" class="searchbtn"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
            <button class="searchclose"><i class="fa-solid fa-xmark"></i></button>
        </div>
    </div>
    <div class="mensign">
        <a class="menbtn1a" href="signinhtml.php"><button class="menbtn1">log in</button></a>
        <a href="adminhtml.php"><button class="menbtn2">Admin</button></a>
    </div>
</div>
<div class="searchglav">
    <h1>Result of search</h1>
    <div class="search1">
    </div>
</div>
<div class="glav">
    <div class="glav1">
        <div class="glavtext">
            <h1>ShowHub</h1>
            <h2>enjoy watching</h2>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enimad minim veniam, quis nostrud exerci Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enimad minim veniam, quis nostrud exerci</p>
            <button>start now</button>
        </div>
        <div class="glavimg">
            <img src="img/glavimg.png" alt="">
        </div>
    </div>
</div>
<div class="top">
    <div class="top1">
        <div class="top1_1">
            <h1>movies</h1>
        </div>
    </div>
    <div class="top2">
        <div class="owl-carousel owl-theme top_cont">
            <div class="top2_1">
                <img src="img/top1.png" alt="">
                <button class="start-now"><span>smaile</span><i></i></button>
            </div>
            <div class="top2_1">
                <img src="img/top2.png" alt="">
                <button class="start-now"><span>breaking bad</span><i></i></button>
            </div>
            <div class="top2_1">
                <img src="img/top3.png" alt="">
                <button class="start-now"><span>the witcher</span><i></i></button>
            </div>
            <div class="top2_1">
                <img src="img/top4.png" alt="">
                <button class="start-now"><span>you</span><i></i></button>
            </div>
        </div>
    </div>
</div>
<div class="principal">
    <h1>principal service</h1>
    <div class="principal1">
        <div class="principal2">
            <div class="principal2_1">
                <h2>basic</h2>
            </div>
            <div class="principal2_2">
                <h3>Watch all you want. Ad-free.</h3>
            </div>
            <div class="principal2_2">
                <h3>Recommendations just for you.
                </h3>
            </div>
            <div class="principal2_2">
                <h3>Change or cancel your plan anytime.
                </h3>
            </div>
            <div class="principal2_2">
                <h3>Resolution <span>480p</span></h3>
            </div>
            <div class="principal2_2">
                <h3>Video qualit <span>Good</span></h3>
            </div>
            <div class="principal2_2">
                <h3>Monthly price <span>MAD65</span></h3>
            </div>
            <div class="principal2_3">
                <h4>buy</h4>
            </div>
        </div>
        <div class="principal2">
            <div class="principal2_1">
                <h2>standart</h2>
            </div>
            <div class="principal2_2">
                <h3>Watch all you want. Ad-free.</h3>
            </div>
            <div class="principal2_2">
                <h3>Recommendations just for you.
                </h3>
            </div>
            <div class="principal2_2">
                <h3>Change or cancel your plan anytime.
                </h3>
            </div>
            <div class="principal2_2">
                <h3>Resolution <span>1080p</span></h3>
            </div>
            <div class="principal2_2">
                <h3>Video qualit <span>Better</span></h3>
            </div>
            <div class="principal2_2">
                <h3>Monthly price <span>MAD95</span></h3>
            </div>
            <div class="principal2_3">
                <h4>buy</h4>
            </div>
        </div>
        <div class="principal2">
            <div class="principal2_1">
                <h2>basic</h2>
            </div>
            <div class="principal2_2">
                <h3>Watch all you want. Ad-free.</h3>
            </div>
            <div class="principal2_2">
                <h3>Recommendations just for you.
                </h3>
            </div>
            <div class="principal2_2">
                <h3>Change or cancel your plan anytime.
                </h3>
            </div>
            <div class="principal2_2">
                <h3>Resolution <span>4K+HDR</span></h3>
            </div>
            <div class="principal2_2">
                <h3>Video qualit <span>Best</span></h3>
            </div>
            <div class="principal2_2">
                <h3>Monthly price <span>MAD125</span></h3>
            </div>
            <div class="principal2_3">
                <h4>buy</h4>
            </div>
        </div>
    </div>
</div>
<footer>
    <div class="footer-cont">
        <div class="footer-block">
            <div class="footer-line">
                <h4>
                    <i class="fa-solid fa-link"></i>
                    social media linkss
                </h4>
            </div>
            <div class="footer-block-div">
                <div class="footer-line-a">
                    <a href="">
                        <i class="fa-brands fa-github"></i>
                    </a>
                    <a href="">
                        nourddine benyahya
                    </a>
                </div>

                <div class="footer-line-a">
                    <a href="">
                        <i class="fa-brands fa-linkedin-in"></i>
                    </a>
                    <a href="">
                        nourddine benyahya
                    </a>
                </div>

                <div class="footer-line-a">
                    <a href="">
                        <i class="fa-brands fa-twitter"></i>
                    </a>
                    <a href="">
                        EedinNour
                    </a>
                </div>

                <div class="footer-line-a">
                    <a href="">
                        <i class="fa-solid fa-phone-volume"></i>
                    </a>
                    <a href="">
                        +212607-081298
                    </a>
                </div>

                <div class="footer-line-a">
                    <a href="">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>
                    <a href="">
                        nourddine ben
                    </a>
                </div>

            </div>
        </div>



        <div class="footer-block-mid">
            <div class="footer-line">
                <h4>
                    <i class="fa-solid fa-link"></i>
                    sponsors
                </h4>
            </div>
            <div class="footer-block-midle">
                <div class="footer-line-a">
                    <a href="">
                        Cisco - Amazon - Google -Azure - LinkedIn
                    </a>
                </div>

                <div class="footer-line-a">
                    <a href="">
                        IBM -Facebook -Tesla - Appel -Microsoft
                    </a>
                </div>
                <div class="footer-line-a">
                    <a href="">
                        Ofppt - 1337
                    </a>
                </div>
            </div>
        </div>


        <div class="footer-block-right">
            <div class="footer-line">
                <h4>
                    <i class="fa-solid fa-link"></i>
                    company
                </h4>
            </div>
            <div class="footer-block-rigt">
                <div class="footer-line-a">
                    <a href="">Register</a>
                    <a href="">Login</a>
                </div>

                <div class="footer-line-a">
                    <a href="">Wishlist</a>
                    <a href="">Our Products</a>
                </div>
                <div class="footer-search">
                    <input type="text" placeholder="Search">
                </div>
            </div>
        </div>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM="
        crossorigin="anonymous"></script>
<script src="js/scriptsearch.js"></script>
<script src="js/scriptsignin.js"></script>
<script src="js/scriptcatalog.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/scriptfilm.js"></script>
<script src="js/scriptlogout.js"></script>
<script src="js/script.js"></script>
</body>
</html>
