$(document).ready(function () {
    $(".searchbtn").click(function (e) {
        e.preventDefault();

        $(`input`).removeClass('error');
        $(".searchglav").css({
            display:"block"
        })
        $(".searchbtn").css({
            display:"none"
        })
        $(".searchclose").css({
            display:"block"
        })

        let search = $('input[name="search"]').val();

        $.ajax({
            url: 'config/search.php',
            type: 'GET',
            dataType: 'json',
            data: {
                search: search
            },
            success(data) {
                if (data.status) {
                    let film = data.message;
                    for (let i = 0; i < film.length; i++) {
                        $(".search1").append("<div class=\"search2\" id="+film[i][0]+"><div class=\"searchimg\"><img src=" + film[i][5] + " alt=\"\"></div><div class=\"searchtext\"><h2>" + film[i][1] + "</h2><h3>date: " + film[i][2] + "</h3><p>" + film[i][4] + "</p></div></div>")
                    }
                } else {
                    if (data.type === 1) {
                        $(`input[name="search"]`).addClass('error')
                    } else if (data.type === 2) {
                        $(".search1 h1").html(data.message).css({
                            color:"red"
                        })
                    }
                }
            }
        });
    })
    $(".searchclose").click(function(){
        $(".searchglav").css({
            display:"none"
        })
        $(".searchbtn").css({
            display:"block"
        })
        $(".searchclose").css({
            display:"none"
        })
        location.reload();
    })
})