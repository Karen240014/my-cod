$(document).ready(function(){
    // $(".menbtn1").click(function (){
    //     $(".opacity").fadeIn(600)
    //     $(".sign").fadeIn(600)
    // })
    // $(".menbtn2").click(function (){
    //     $(".opacity").fadeIn(600)
    //     $(".sign").fadeIn(600)
    // })
    // $(".signclose button").click(function (){
    //     $(".opacity").fadeOut(600)
    //     $(".sign").fadeOut(600)
    // })
    // $(".signreg a").click(function (){
    //     $(".opacity").fadeIn(600)
    //     $(".reg").fadeIn(600)
    //     $(".sign").fadeOut(600)
    // })
    // $(".regclose button").click(function (){
    //     $(".opacity").fadeOut(600)
    //     $(".reg").fadeOut(600)
    // })
    // $(".regsign a").click(function (){
    //     $(".opacity").fadeIn(600)
    //     $(".reg").fadeOut(600)
    //     $(".sign").fadeIn(600)
    // })
    $('.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            900:{
                items:2
            },
            1100:{
                items:3
            },
            1500:{
                items:4
            }
        }
    })
})
