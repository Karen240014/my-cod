$(document).ready(function () {
    $('.register-btn').click(function (e) {
        e.preventDefault();

        $(`input`).removeClass('error');

        let email = $('input[name="email"]').val(),
            username = $('input[name="username"]').val(),
            password = $('input[name="password"]').val(),
            password_confirm = $('input[name="password_confirm"]').val();

        $.ajax({
            url: 'config/signup.php',
            type: 'POST',
            dataType: 'json',
            data: {
                email: email,
                password: password,
                username: username,
                password_confirm: password_confirm,
            },
            success(data) {

                if (data.status) {
                    $(".regform").html("<h5 class=\"msg1\">регистрация прошла успешна <br> перейти в <a href='../signinhtml.php'>Sign in</a></h5>")
                } else {

                    if (data.type === 1) {
                        data.fields.forEach(function (field) {
                            $(`input[name="${field}"]`).addClass('error');
                        });
                    }
                    $('.msg').removeClass('none').text(data.message);
                    $('.msg').addClass('msg2')
                }

            }
        });

    });
})