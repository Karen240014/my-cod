$(document).ready(function () {
    $('.login_btn').click(function (e) {
        e.preventDefault();

        $(`input`).removeClass('error');

        let email = $('input[name="email"]').val(),
            password = $('input[name="password"]').val();

        $.ajax({
            url: 'config/signin.php',
            type: 'POST',
            dataType: 'json',
            data: {
                email: email,
                password: password
            },
            success(data) {
                if (data.status) {
                    document.location.href = '/profilehtml.php';
                } else {

                    if (data.type === 1) {
                        data.fields.forEach(function (field) {
                            $(`input[name="${field}"]`).addClass('error');
                        });
                    }
                    $('.msg').removeClass('none').text(data.message)
                    $('.msg').addClass('msg2')
                }

            }
        });

    });
})
