$(document).ready(function(){
    $.ajax({
        url: 'config/catalog.php',
        type: 'POST',
        dataType: 'json',

        success(data) {
            let film = data;
            for(let i=0; i<film.length; i++){
                $(".cat1").append("<a href='/filmhtml.php?id="+film[i][0]+"'><div class=\"cat2\" id="+film[i][0]+"><div class=\"catimg\"><img src="+film[i][5]+" alt=\"\"></div><div class=\"cattext\"><h2>"+film[i][1]+"</h2><h3>date: "+film[i][2]+"</h3><p>"+film[i][4]+"</p></div></div></a>")
            }
        }
    });
})