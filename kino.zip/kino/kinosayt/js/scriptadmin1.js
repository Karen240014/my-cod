$(document).ready(function () {

        $.ajax({
            url: 'config/admin1.php',
            type: 'POST',
            dataType: 'json',

            success(data) {
                let rej=data.rej
                let rejid=data.rejid
                for(let i=0; i<rej.length; i++){
                    $(".rejselect").append("<option value="+rejid[i]+">"+rej[i]+"</option>")
                }

                let act=data.act
                let actid=data.actid
                for(let i=0; i<act.length; i++){
                    $(".actselect").append("<option value="+actid[i]+">"+act[i]+"</option>")
                }

                let years=data.years
                let yearsid=data.yearsid
                for(let i=0; i<years.length; i++){
                    $(".yearsselect").append("<option value="+yearsid[i]+">"+years[i]+"</option>")
                }

                let janre=data.janre
                let janreid=data.janreid
                for(let i=0; i<janre.length; i++){
                    $(".janreselect").append("<option value="+janreid[i]+">"+janre[i]+"</option>")
                }
            }
        });
})