$(document).ready(function () {
    $(".ac_exit").click(function (e){
        e.preventDefault()
        document.location.href = '/index.php';
    })
})