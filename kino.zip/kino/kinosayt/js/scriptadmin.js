$(document).ready(function () {

    let nkar=false
    $('input[name="img"]').change(function(e){
        nkar=e.target.files[0]
    })

    $('.adm_done').click(function (e) {
        e.preventDefault();

        $(`input`).removeClass('error');

        let filmname = $('input[name="filmname"]').val(),
            rejisor = $('select[name="rejisor"]').val(),
            actors = $('select[name="actors"]').val(),
            year = $('select[name="year"]').val(),
            janre = $('select[name="janre"]').val(),
            description = $('input[name="description"]').val();


            let formData = new FormData()
            formData.append('filmname',filmname)
            formData.append('rejisor',rejisor)
            formData.append('actors',actors)
            formData.append('year',year)
            formData.append('description',description)
            formData.append('janre',janre)
            formData.append('img',nkar)

        $.ajax({
            url: 'config/admin.php',
            type: 'POST',
            dataType: 'json',
            processData:false,
            contentType: false,
            cache: false,
            data: formData,
            success(data) {

                if (data.status) {
                    $(".admform").html("<h5 class=\"msg1\">филь добавлен <br> перейти в <a href='../index.php'>Главную страницу</a></h5>")
                } else {

                    if (data.type === 1) {
                        data.fields.forEach(function (field) {
                            $(`input[name="${field}"]`).addClass('error');
                        });
                    }
                    $('.msg').removeClass('none').text(data.message);
                    $('.msg').addClass('msg2')
                }

            }
        });

    });
})