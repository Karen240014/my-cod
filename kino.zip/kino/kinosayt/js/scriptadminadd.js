$(document).ready(function () {
    $('.add_done').click(function (e) {
        e.preventDefault();

        $(`input`).removeClass('error');

        let directorname = $('input[name="directorname"]').val(),
            actorname = $('input[name="actorname"]').val();

        $.ajax({
            url: 'config/adminadd.php',
            type: 'POST',
            dataType: 'json',
            data: {
                directorname:directorname,
                actorname:actorname
            },
            success(data) {

                if (data.status) {
                    $(".addform").html("<h5 class=\"msg1\">данные добавлены успешно <br> перейти в <a href='../adminhtml.php'>admin</a></h5>")
                } else {

                    if (data.type === 1) {
                        data.fields.forEach(function (field) {
                            $(`input[name="${field}"]`).addClass('error');
                        });
                    }
                    $('.msg').removeClass('none').text(data.message);
                    $('.msg').addClass('msg2')
                }

            }
        });

    });
})