$(document).ready(function () {
    $(".cat2").click(function(){
        var divid = $(this).attr("id");
        console.log(divid)
        $.ajax({
            url: 'config/film.php',
            type: 'POST',
            dataType: 'json',

            success(data) {
                let film = data;
                console.log(film)

                for(let i=0; i<film.length; i++){
                    if(divid == film[i][0]){
                        $(".film1").append("<h1>"+film[i][1]+"</h1>\n" +
                            "        <div class=\"filmdescript\">\n" +
                            "            <div class=\"filmdesimg\">\n" +
                            "                <img src="+film[i][5]+" alt=\"\">\n" +
                            "            </div>\n" +
                            "            <div class=\"filmdestext\">\n" +
                            "                <h2>Year: <span>"+film[i][2]+"</span></h2>\n" +
                            "                <h2>Rejisor: <span>"+film[i][3]+"</span></h2>\n" +
                            "                <h2>Actors: <span>"+film[i][6]+"</span></h2>\n" +
                            "                <h2>Genre: <span>"+film[i][7]+"</span></h2>\n" +
                            "                <h2>Description: <span>"+film[i][4]+"</span></h2>\n" +
                            "            </div>\n" +
                            "        </div>\n" +
                            "        <div class=\"filmvideo\">\n" +
                            "            <img src=\"img/vid.jpg\" alt=\"\">\n" +
                            "        </div>")
                    }
                }
                document.location.href = '/filmhtml.php';
            }
        });
    })
})