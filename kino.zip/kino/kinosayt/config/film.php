<?php
require_once "connect.php";
$sql = "SELECT
       films.id_film,
       films.film_name,
       years.years,
       rejisor.rejisor,
       films.film_descript,
       films.film_img
FROM films
INNER JOIN years
    ON films.id_year=years.year_id
INNER JOIN rejisor
    ON films.id_rej=rejisor.rej_id
";

$result = mysqli_query($link, $sql);
$cat_arr = mysqli_fetch_all($result);
for($i=0; $i<count($cat_arr); $i++){
    $id=$cat_arr[$i][0];
    $sqlact="SELECT GROUP_CONCAT(actors.actor) as actor FROM actor_film
LEFT JOIN films ON films.id_film=actor_film.id_film
LEFT JOIN actors ON actors.actor_id=actor_film.id_actor
WHERE films.id_film='$id'";
    $actres=mysqli_query($link, $sqlact);
    $actarr=mysqli_fetch_array($actres);
    $actor=$actarr["actor"];
    $cat_arr[$i][]=$actor;
}
for($i=0; $i<count($cat_arr); $i++){
    $id=$cat_arr[$i][0];
    $sqljan="SELECT GROUP_CONCAT(janre.janre) as janre FROM janre_film
LEFT JOIN films ON films.id_film=janre_film.id_film
LEFT JOIN janre ON janre.janre_id=janre_film.id_janre
WHERE films.id_film='$id'";
    $janres=mysqli_query($link, $sqljan);
    $janarr=mysqli_fetch_array($janres);
    $janre=$janarr["janre"];
    $cat_arr[$i][]=$janre;
}
