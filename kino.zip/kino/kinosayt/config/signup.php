<?php
session_start();
require_once "connect.php";
$username = $_POST["username"];
$email = $_POST["email"];
$password = $_POST["password"];
$password_confirm = $_POST["password_confirm"];

$check_login=mysqli_query($link, "SELECT * FROM `users` WHERE `username`='$username'");
if(mysqli_num_rows($check_login)>0){
    $response=[
        "status"=>false,
        "message"=>"имя занято",
        "type"=>1,
        "fields"=>['username']
    ];

    echo json_encode($response);
    die();
}
$check_email=mysqli_query($link, "SELECT * FROM `users` WHERE `email`='$email'");
if(mysqli_num_rows($check_email)>0){
    $response=[
        "status"=>false,
        "message"=>"почта занята",
        "type"=>1,
        "fields"=>['email']
    ];

    echo json_encode($response);
    die();
}

$error_fields = [];

if ($email == "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error_fields[] = "email";
}

if ($password == "") {
    $error_fields[] = "password";
}
if ($username== "") {
    $error_fields[] = "username";
}
if ($password_confirm == "") {
    $error_fields[] = "password_confirm";
}

if (!empty($error_fields)) {
    $response = [
        "status" => false,
        "type" => 1,
        "message" => "заполните все поля",
        "fields" => $error_fields
    ];

    echo json_encode($response);

    die();
}


if ($password === $password_confirm) {

    $password = password_hash($password, PASSWORD_BCRYPT, ["cost"=>12]);

    $sql="INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES (NULL, '$username', '$email', '$password')";
    $result=mysqli_query($link, $sql);

    $response = [
        "status" => true,
        "message" => "Регистрация прошла успешно!",
    ];
    echo json_encode($response);


} else {
    $response = [
        "status" => false,
        "message" => "Пароли не совпадают",
    ];
    echo json_encode($response);
}

