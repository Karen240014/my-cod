<?php
session_start();
require_once "connect.php";
$filmname = $_POST["filmname"];
$rejisor = $_POST["rejisor"];
$actors = $_POST["actors"];
$year = $_POST["year"];
$janre = $_POST["janre"];
$description = $_POST["description"];

$check_filmname = mysqli_query($link, "SELECT * FROM `films` WHERE `film_name`='$filmname'");
if (mysqli_num_rows($check_filmname) > 0) {
    $response = [
        "status" => false,
        "message" => "имя занято",
        "type" => 1,
        "fields" => ['filmname']
    ];

    echo json_encode($response);
    die();
}

$error_fields = [];

if ($filmname == "") {
    $error_fields[] = "filmname";
}

if (!$rejisor) {
    $error_fields[] = "rejisor";
}
if (!$actors) {
    $error_fields[] = "actors";
}
if (!$year) {
    $error_fields[] = "year";
}
if (!$janre) {
    $error_fields[] = "janre";
}
if ($description == "") {
    $error_fields[] = "description";
}
if (!$_FILES["img"]) {
    $error_fields[] = "img";
}

if (!empty($error_fields)) {
    $response = [
        "status" => false,
        "type" => 1,
        "message" => "заполните все поля",
        "fields" => $error_fields
    ];

    echo json_encode($response);

    die();
} else {

    $nkar = 'filmimg/'.$_FILES['img']['name'];
    if(!move_uploaded_file($_FILES['img']['tmp_name'], '../'.$nkar)){
        $response = [
            "status" => false,
            "type" => 2,
            "message" => "ошибка при загрузке",
        ];
        echo json_encode($response);
    }

    $sql = "INSERT INTO `films` (`id_film`, `film_name`, `id_year`, `id_rej`, `film_descript`, `film_img`) VALUES (NULL, '$filmname', '$year', '$rejisor', '$description','$nkar')";
    $result = mysqli_query($link, $sql);

    $last_id = mysqli_insert_id($link);
    $actorsarr=explode(",",$actors);
    foreach ($actorsarr as $actorsf){
        mysqli_query($link, "INSERT INTO `actor_film` (`id`, `id_film`, `id_actor`) VALUES (NULL, '$last_id', '$actorsf')");
    }
    $janrearr=explode(",",$janre);
    foreach ($janrearr as $janref){
        mysqli_query($link, "INSERT INTO `janre_film` (`id`, `id_film`, `id_janre`) VALUES (NULL, '$last_id', '$janref')");
    }



    $response = [
        "status" => true,
        "message" => "Фильм добавлен успешно!",
    ];
    echo json_encode($response);
}
