<?php
require_once "connect.php";
$search=$_GET['search'];
$error_fields = [];

if ($search == "") {
    $error_fields[] = "search";
}
if (!empty($error_fields)) {
    $response = [
        "status" => false,
        "type" => 1,
        "message" => "заполните полe",
        "fields" => $error_fields
    ];

    echo json_encode($response);

    die();
}
if(isset($_GET['search'])){
    $query="SELECT * FROM films WHERE CONCAT(film_name,film_descript) LIKE '%$search%'";
    $result=mysqli_query($link, $query);
    if(mysqli_num_rows($result)>0){
        $search_arr=mysqli_fetch_all($result);
        $response = [
            "status" => true,
            "message" => $search_arr,
        ];
        echo json_encode($response);
    }
    else{
        $response = [
            "status" => false,
            "type" => 2,
            "message" => "Ничего не найдено",
        ];

        echo json_encode($response);

        die();
    }
}
