<?php
require_once "connect.php";
$sql="SELECT rejisor FROM rejisor";
$sql1="SELECT actor FROM actors";
$sql2="SELECT years FROM years";
$sql3="SELECT janre FROM janre";
$sql4="SELECT rej_id FROM rejisor";
$sql5="SELECT actor_id FROM actors";
$sql6="SELECT year_id FROM years";
$sql7="SELECT janre_id FROM janre";
$rej=mysqli_query($link,$sql);
$act=mysqli_query($link,$sql1);
$years=mysqli_query($link,$sql2);
$janre=mysqli_query($link,$sql3);
$rejid=mysqli_query($link,$sql4);
$actid=mysqli_query($link,$sql5);
$yearsid=mysqli_query($link,$sql6);
$janreid=mysqli_query($link,$sql7);
$rej1=mysqli_fetch_all($rej);
$act1=mysqli_fetch_all($act);
$years1=mysqli_fetch_all($years);
$janre1=mysqli_fetch_all($janre);
$rejid1=mysqli_fetch_all($rejid);
$actid1=mysqli_fetch_all($actid);
$yearsid1=mysqli_fetch_all($yearsid);
$janreid1=mysqli_fetch_all($janreid);
    $response = [
        "rej" => $rej1,
        "act" => $act1,
        "years" => $years1,
        "janre"=> $janre1,
        "rejid" => $rejid1,
        "actid" => $actid1,
        "yearsid" => $yearsid1,
        "janreid"=> $janreid1
    ];

    echo json_encode($response);


