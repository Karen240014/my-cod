<?php
session_start();
require_once "connect.php";
$email = $_POST["email"];
$password = $_POST['password'];
$error_fields = [];
if ($email == "") {
    $error_fields[] = "email";
}
if ($password == "") {
    $error_fields[] = "password";
}
if (!empty($error_fields)) {
    $response = [
        "status" => false,
        "type" => 1,
        "fields" => $error_fields,
        "message" => "заполните все поля"
    ];

    echo json_encode($response);

    die();
}

$sql = "SELECT * FROM users WHERE email='$email'";

$check_user = mysqli_query($link, $sql);

$user = mysqli_fetch_array($check_user, MYSQLI_ASSOC);

if (password_verify($password, $user['password'])) {


    $_SESSION['user'] = [
        "id" => $user["id"],
        "username" => $user["username"],
        "email" => $user["email"]
    ];


    $response = [
        "status" => true,
    ];

    echo json_encode($response);
} else {
    $response = [
        "status" => false,
        "message" => "неверные данные"
    ];
    echo json_encode($response);
}


