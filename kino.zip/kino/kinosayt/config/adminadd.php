<?php
session_start();
require_once "connect.php";
$directorname = $_POST["directorname"];
$actorname = $_POST["actorname"];
$actornamearr=explode(",",$actorname);

$check_directorname = mysqli_query($link, "SELECT * FROM `rejisor` WHERE `rejisor`='$directorname'");
if (mysqli_num_rows($check_directorname) > 0) {
    $response = [
        "status" => false,
        "message" => "Режисер есть в базе данных",
        "type" => 1,
        "fields" => ['directorname']
    ];

    echo json_encode($response);
    die();
}

$stugum=0;
for($i=0; $i<count($actornamearr); $i++) {
    $check_actorname = mysqli_query($link, "SELECT * FROM `actors` WHERE `actor`='$actornamearr[$i]'");
    if (mysqli_num_rows($check_actorname) > 0) {
        $stugum++;
    }
}
if($stugum>0){
    $response = [
        "status" => false,
        "type" => 1,
        "message" => "актер есть в базе данных",
        "fields" => ["actorname"]
    ];

    echo json_encode($response);

    die();
}

$error_fields = [];
if ($directorname== "") {
    $error_fields[] = "directorname";
}
if ($actorname == "") {
    $error_fields[] = "actorname";
}
if (!empty($error_fields)) {
    $response = [
        "status" => false,
        "type" => 1,
        "message" => "заполните все поля",
        "fields" => $error_fields
    ];

    echo json_encode($response);

    die();
}



    $sql = "INSERT INTO `rejisor` (`rej_id`, `rejisor`) VALUES (NULL, '$directorname')";
    $result = mysqli_query($link, $sql);

    foreach ($actornamearr as $actornamef) {
        mysqli_query($link, "INSERT INTO `actors` (`actor_id`, `actor`) VALUES (NULL, '$actornamef')");
    }


    $response = [
        "status" => true,
        "message" => "Фильм добавлен успешно!",
    ];
    echo json_encode($response);



