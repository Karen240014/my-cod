<?php
require_once "connect.php";
$sql = "SELECT
       films.id_film,
       films.film_name,
       years.years,
       rejisor.rejisor,
       films.film_descript,
       films.film_img
FROM films
INNER JOIN years
    ON films.id_year=years.year_id
INNER JOIN rejisor
    ON films.id_rej=rejisor.rej_id
";

$result = mysqli_query($link, $sql);
$cat_arr = mysqli_fetch_all($result);
echo json_encode($cat_arr);





