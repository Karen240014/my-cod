-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 22 2023 г., 15:51
-- Версия сервера: 5.7.39-log
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kinosayt`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actors`
--

CREATE TABLE `actors` (
  `actor_id` int(11) NOT NULL,
  `actor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `actors`
--

INSERT INTO `actors` (`actor_id`, `actor`) VALUES
(1, 'Ryan Reynolds'),
(2, 'Pedro Pascal'),
(3, 'Chris Hemsworth'),
(4, 'Benedict Cumberbatch'),
(5, 'Tom Holland'),
(6, 'Colin Farrell'),
(7, 'Andrew Garfield'),
(8, 'Jake Gyllenhaal'),
(9, 'Tom Cruise'),
(10, 'Mark Wahlberg'),
(11, 'Dwayne Johnson'),
(12, 'Jim Carrey'),
(13, 'Mark Ruffalo'),
(14, 'Matt Damon'),
(15, 'Chris Pratt'),
(16, 'Adam Sandler'),
(17, 'Viggo Mortensen'),
(18, 'Tobey Maguire'),
(19, 'John C. Reilly'),
(20, 'Jason Momoa'),
(21, 'Sebastian Stan'),
(22, 'James Marsden'),
(23, 'Kenneth Branagh'),
(24, 'Lakeith Stanfield'),
(25, 'Josh Hutcherson'),
(26, 'Seth Rogen'),
(27, 'Tom Hanks'),
(28, 'Brad Pitt'),
(29, 'Channing Tatum'),
(30, 'Liev Schreiber'),
(31, 'Miles Teller'),
(32, 'Jan Reno'),
(33, 'jason ststham'),
(34, 'Joseph Gilgun');

-- --------------------------------------------------------

--
-- Структура таблицы `actor_film`
--

CREATE TABLE `actor_film` (
  `id` int(11) NOT NULL,
  `id_film` int(11) NOT NULL,
  `id_actor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `actor_film`
--

INSERT INTO `actor_film` (`id`, `id_film`, `id_actor`) VALUES
(1, 25, 1),
(2, 25, 2),
(3, 25, 14),
(4, 26, 1),
(5, 26, 2),
(6, 26, 13),
(7, 26, 14),
(8, 26, 15),
(14, 27, 1),
(15, 27, 2),
(16, 27, 14),
(17, 27, 33),
(18, 28, 7),
(19, 28, 8),
(20, 28, 13),
(21, 28, 14),
(22, 28, 20),
(23, 29, 7),
(24, 29, 8),
(25, 29, 19),
(26, 29, 20),
(27, 29, 25),
(28, 29, 26),
(29, 30, 7),
(30, 30, 8),
(31, 30, 9),
(32, 30, 19),
(33, 30, 20),
(34, 31, 13),
(35, 31, 14),
(36, 31, 16),
(37, 31, 25),
(38, 31, 27);

-- --------------------------------------------------------

--
-- Структура таблицы `films`
--

CREATE TABLE `films` (
  `id_film` int(11) NOT NULL,
  `film_name` varchar(255) NOT NULL,
  `id_year` int(11) NOT NULL,
  `id_rej` int(11) NOT NULL,
  `film_descript` text NOT NULL,
  `film_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `films`
--

INSERT INTO `films` (`id_film`, `film_name`, `id_year`, `id_rej`, `film_descript`, `film_img`) VALUES
(25, 'Joker', 29, 9, 'Joker is film directed in USA', 'filmimg/joker.png'),
(26, 'Venom', 29, 13, 'Investigative journalist Eddie Brock attempts a comeback following a scandal, but accidentally becomes the host of Venom, a violent, super powerful alien symbiote. Soon, he must rely on his newfound powers to protect the world from a shadowy organization looking for a symbiote of their own.', 'filmimg/venom.jpg'),
(27, 'The Meg', 31, 32, 'A deep sea submersible pilot revisits his past fears in the Mariana Trench, and accidentally unleashes the seventy foot ancestor of the Great White Shark believed to be extinct.', 'filmimg/themeg.jpg'),
(28, 'Shazam', 32, 25, 'A boy is given the ability to become an adult superhero in times of need with a single magic word.', 'filmimg/shazam.jpg'),
(29, 'Venom: Let There Be Carnage', 33, 5, 'After finding a host body in investigative reporter Eddie Brock, the alien symbiote must face a new enemy, Carnage, the alter ego of serial killer Cletus Kasady.', 'filmimg/carnage.jpg'),
(30, 'Godzilla vs Kong', 32, 8, 'In a time when monsters walk the Earth, humanity’s fight for its future sets Godzilla and Kong on a collision course that will see the two most powerful forces of nature on the planet collide in a spectacular battle for the ages.', 'filmimg/Godzilla_vs._Kong.png'),
(31, 'The Nun', 28, 14, 'When a young nun at a cloistered abbey in Romania takes her own life, a priest with a haunted past and a novitiate on the threshold of her final vows are sent by the Vatican to investigate.', 'filmimg/thenun.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `janre`
--

CREATE TABLE `janre` (
  `janre_id` int(11) NOT NULL,
  `janre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `janre`
--

INSERT INTO `janre` (`janre_id`, `janre`) VALUES
(1, 'Action film'),
(2, 'Adventure film'),
(3, 'Comedy film'),
(4, 'Drama'),
(5, 'Fantasy film'),
(6, 'Historical film'),
(7, 'Horror film'),
(8, 'Romance film'),
(9, 'Science fiction film'),
(10, 'Western'),
(11, 'Thriller film'),
(12, 'Musical film'),
(13, 'Noir film'),
(14, 'Mystery film'),
(15, 'Crime thriller');

-- --------------------------------------------------------

--
-- Структура таблицы `janre_film`
--

CREATE TABLE `janre_film` (
  `id` int(11) NOT NULL,
  `id_film` int(11) NOT NULL,
  `id_janre` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `janre_film`
--

INSERT INTO `janre_film` (`id`, `id_film`, `id_janre`) VALUES
(1, 25, 1),
(2, 25, 7),
(3, 25, 15),
(4, 26, 1),
(5, 26, 7),
(9, 27, 1),
(10, 27, 7),
(11, 27, 14),
(12, 28, 2),
(13, 28, 3),
(14, 28, 11),
(15, 29, 1),
(16, 29, 7),
(17, 29, 11),
(18, 29, 15),
(19, 30, 2),
(20, 30, 6),
(21, 30, 7),
(22, 31, 1),
(23, 31, 5),
(24, 31, 7);

-- --------------------------------------------------------

--
-- Структура таблицы `rejisor`
--

CREATE TABLE `rejisor` (
  `rej_id` int(11) NOT NULL,
  `rejisor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `rejisor`
--

INSERT INTO `rejisor` (`rej_id`, `rejisor`) VALUES
(31, 'Abbas Kiarostami'),
(7, 'Alejandro Agresti'),
(9, 'Ari Aster'),
(13, 'Brian Patrick Butler'),
(17, 'Ching Siu-Tung'),
(14, 'David Butler'),
(26, 'David Cronenberg'),
(8, 'Dev Anand'),
(5, 'Dodo Abashidze'),
(25, 'Guillermo del Toro'),
(12, 'Jacques Becker'),
(18, 'Jacques Demy'),
(20, 'John English'),
(24, 'John Irvin'),
(16, 'Kate Cheeseman'),
(10, 'Kostas Andritsos'),
(19, 'Mike Flanagan'),
(6, 'Neil Affleck'),
(22, 'Paul Greengrass'),
(23, 'Paula Heredia'),
(32, 'Pedro Almodovar'),
(11, 'Robert Aldrich'),
(21, 'Theo van Gogh'),
(15, 'Tricia Brock');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(3, 'Aren', 'hovhannisyan.aren.2006@gmail.com', '$2y$12$P/3B4gN21jvOur5JJ/9WZuYqU3sTt3fqWIyWIjMAvCL694EYIoHfq');

-- --------------------------------------------------------

--
-- Структура таблицы `years`
--

CREATE TABLE `years` (
  `year_id` int(11) NOT NULL,
  `years` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `years`
--

INSERT INTO `years` (`year_id`, `years`) VALUES
(1, 1990),
(2, 1991),
(3, 1992),
(4, 1993),
(5, 1994),
(6, 1995),
(7, 1996),
(8, 1997),
(9, 1998),
(10, 1999),
(11, 2000),
(12, 2001),
(13, 2002),
(14, 2003),
(15, 2004),
(16, 2005),
(17, 2006),
(18, 2007),
(19, 2008),
(20, 2009),
(21, 2010),
(22, 2011),
(23, 2012),
(24, 2013),
(25, 2014),
(26, 2015),
(27, 2016),
(28, 2017),
(29, 2018),
(30, 2019),
(31, 2020),
(32, 2021),
(33, 2022),
(34, 2023),
(35, 2024);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `actors`
--
ALTER TABLE `actors`
  ADD PRIMARY KEY (`actor_id`);

--
-- Индексы таблицы `actor_film`
--
ALTER TABLE `actor_film`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_film` (`id_film`),
  ADD KEY `id_actor` (`id_actor`) USING BTREE;

--
-- Индексы таблицы `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id_film`),
  ADD KEY `id_year` (`id_year`),
  ADD KEY `id_rej` (`id_rej`);

--
-- Индексы таблицы `janre`
--
ALTER TABLE `janre`
  ADD PRIMARY KEY (`janre_id`);

--
-- Индексы таблицы `janre_film`
--
ALTER TABLE `janre_film`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_film` (`id_film`),
  ADD KEY `id_ganre` (`id_janre`) USING BTREE;

--
-- Индексы таблицы `rejisor`
--
ALTER TABLE `rejisor`
  ADD PRIMARY KEY (`rej_id`),
  ADD UNIQUE KEY `rejisor` (`rejisor`),
  ADD UNIQUE KEY `rejisor_2` (`rejisor`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `years`
--
ALTER TABLE `years`
  ADD PRIMARY KEY (`year_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `actors`
--
ALTER TABLE `actors`
  MODIFY `actor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT для таблицы `actor_film`
--
ALTER TABLE `actor_film`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT для таблицы `films`
--
ALTER TABLE `films`
  MODIFY `id_film` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT для таблицы `janre`
--
ALTER TABLE `janre`
  MODIFY `janre_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `janre_film`
--
ALTER TABLE `janre_film`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `rejisor`
--
ALTER TABLE `rejisor`
  MODIFY `rej_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `years`
--
ALTER TABLE `years`
  MODIFY `year_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `actor_film`
--
ALTER TABLE `actor_film`
  ADD CONSTRAINT `actor_film_ibfk_1` FOREIGN KEY (`id_film`) REFERENCES `films` (`id_film`),
  ADD CONSTRAINT `actor_film_ibfk_2` FOREIGN KEY (`id_actor`) REFERENCES `actors` (`actor_id`);

--
-- Ограничения внешнего ключа таблицы `films`
--
ALTER TABLE `films`
  ADD CONSTRAINT `films_ibfk_1` FOREIGN KEY (`id_year`) REFERENCES `years` (`year_id`),
  ADD CONSTRAINT `films_ibfk_2` FOREIGN KEY (`id_rej`) REFERENCES `rejisor` (`rej_id`);

--
-- Ограничения внешнего ключа таблицы `janre_film`
--
ALTER TABLE `janre_film`
  ADD CONSTRAINT `janre_film_ibfk_1` FOREIGN KEY (`id_film`) REFERENCES `films` (`id_film`),
  ADD CONSTRAINT `janre_film_ibfk_2` FOREIGN KEY (`id_janre`) REFERENCES `janre` (`janre_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
