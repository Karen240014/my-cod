<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="glavsignup">
    <div class="reg">
        <div class="regclose"><a href="index.php">
                <a href="signinhtml.php"><button><i class="fa-solid fa-xmark"></i></button></a>
            </a></div>
        <h1>ShowHub</h1>
        <h2>Sign in to ShowHub</h2>
        <div class="regform">
            <form action="config/signup.php" method="post" name="signup" enctype="multipart/form-data">
                <h3>username</h3>
                <input type="text" name="username">
                <h3>email </h3>
                <input type="text" name="email">
                <h3>Password</h3>
                <input type="password" name="password">
                <h3>confirm password</h3>
                <input type="password" name="password_confirm">
                <h4 class="msg none"></h4>
                <br>
                <button type="submit" class="register-btn">Sign up</button>
            </form>
        </div>
        <div class="regsign">
            <h4>already have a account? <a href="signinhtml.php"> Sign in</a> .</h4>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM="
        crossorigin="anonymous"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/scriptsignup.js"></script>
</body>
</html>
