<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/1f21eb1afe.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="menu">
    <div class="menu1">
        <div class="menlogo">
            <a href="index.php"><h1>ShowHub</h1></a>
        </div>
        <div class="mentext">
            <a href="cataloghtml.php">Movies</a>
            <a href="">Series</a>
            <a href="">Contact</a>
            <a href="">About Us</a>
            <div class="mediamen">
                <div class="mediamen1">
                    <h4>menu <i class="fa-solid fa-chevron-down"></i></h4>
                </div>
                <div class="mediamen2">
                    <a href="cataloghtml.php">Movies</a>
                    <a href="">Series</a>
                    <a href="">Contact</a>
                    <a href="">About Us</a>
                </div>
            </div>
        </div>
        <div class="meninp">
            <form action="config/search.php" method="get" enctype="multipart/form-data">
                <input type="text" required placeholder="Search" name="search">
                <button type="submit" class="searshbtn"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
        </div>
    </div>
    <div class="mensign">
        <a class="menbtn1a" href="signinhtml.php"><button class="menbtn1">log in</button></a>
        <a href="adminhtml.php"><button class="menbtn2">Admin</button></a>
    </div>
</div>
<div class="catglav">
    <h1>All films</h1>
    <div class="cat1">
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
<script src="js/scriptsignin.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/scriptlogout.js"></script>
<script src="js/script.js"></script>
<script src="js/scriptcatalog.js"></script>
<script src="js/scriptfilm.js"></script>
</body>
</html>
