$(document).ready(function(){
	$(".divj").click(function(){
		$(".menu").removeClass("menuN")
	})
	$(".text1").click(function(){
		$(".menu").addClass("menuN")
	})
});