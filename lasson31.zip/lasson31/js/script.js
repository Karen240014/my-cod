// var div = document.querySelectorAll(".gndak");
// for (let i = 0; i < div.length; i++){
// }
// function xax(){
// 	var a = parseInt (Math.random() * 300);
// 	var b = parseInt (Math.random() * 600);
// }




var div = document.querySelectorAll(".gndak");
function xax(){
	for (let i = 0; i < div.length; i++){
		var a = parseInt (Math.random() * 300);
		var b = parseInt (Math.random() * 600);
		div[i].style.top=a+"px"
		div[i].style.left=b+"px"
	}
}

